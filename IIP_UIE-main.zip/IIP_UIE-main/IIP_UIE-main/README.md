# iip_under-water_image_enhancement
                                                Under Water Image Enhancement 
                                       Introduction to Innovative Projects(PHY1901)
                                                    Winter Semester2021 
                                                          
                                                         
The main objective of this project is to use an image enhancement mechanism to process the input image to make it more appropriate and clearly visible for the required application. Image enhancement intensifies the features of images and makes images more clearly visible.
Not like all others, our aim is to develop an image enhancement technology with the Graphical User Interface.
